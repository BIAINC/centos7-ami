# Systemd Service

Sample configuration of `systemd` service file for Teleport
