#!/bin/bash
teleport start -c teleport.yaml -d
